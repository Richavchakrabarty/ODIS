-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 24, 2017 at 07:54 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `onlinedis`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` varchar(10) NOT NULL,
  `pass` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `pass`) VALUES
('Admin', 'odis');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `dname` varchar(20) NOT NULL,
  `floor` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  PRIMARY KEY (`dname`),
  KEY `dname` (`dname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dname`, `floor`, `email`) VALUES
('Accident & emergency', 'Ground', 'a&e@gmail.com'),
('Ear nose throat(ENT)', '1st', 'ent@gmail.com'),
('General surgery', '2nd', 'g_surgery@hotmail.com'),
('Microbiology', '3rd', 'microb@yahoo.com'),
('Neurology', '4th', 'neuro@rediffmail.com'),
('Orthopaedics', '5th', 'ortho@mail.com'),
('Urology', '6th', 'uro@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `department_mobile`
--

CREATE TABLE IF NOT EXISTS `department_mobile` (
  `dname` varchar(20) NOT NULL,
  `mobile_no` varchar(13) NOT NULL,
  PRIMARY KEY (`dname`,`mobile_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_mobile`
--


-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `did` varchar(15) NOT NULL,
  `dname` varchar(20) NOT NULL,
  `fname` varchar(15) NOT NULL,
  `mname` varchar(15) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `demail` varchar(40) NOT NULL,
  `state` varchar(10) NOT NULL,
  `dist` varchar(10) NOT NULL,
  `hno` varchar(10) NOT NULL,
  `po` varchar(10) NOT NULL,
  `ps` varchar(10) NOT NULL,
  `pin` int(6) NOT NULL,
  `specialization` varchar(20) NOT NULL,
  PRIMARY KEY (`did`),
  KEY `dname` (`dname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`did`, `dname`, `fname`, `mname`, `lname`, `gender`, `demail`, `state`, `dist`, `hno`, `po`, `ps`, `pin`, `specialization`) VALUES
('hk1', 'General surgery', ' Harsh', '', 'Kumar', 'Male', 'harsh@yahoo.com', 'Assam', 'Ghy', '30', 'Kachari', 'Panbazar', 781001, 'MBBS,MS'),
('PG032', 'Accident & emergency', 'Parampreet', '', 'Ghuman', 'Female', 'parampreet@rediffmail.com', 'Assam', 'Kamrup', '101', 'pandu', 'Jalukbari', 781012, 'MD'),
('priya06', 'Neurology', 'Bhanu', '', 'Priya', 'Female', 'priya@outlook.com', 'Assam', 'Jorhat', '4', 'jorhat', 'Jorhat', 785012, 'PGD'),
('ravi23', 'Microbiology', 'Ravinder', '', 'Puri', 'Male', 'ravi@gmail.com', 'Assam', 'Nalbari', '55', 'Nalbari', 'Nalbari', 781303, 'MD'),
('vjs43', 'Ear nose throat(ENT)', 'VJS', '', 'Virdi', 'Male', 'vjs@gmail.com', 'Assam', 'Gauhati', '053', 'Noonmati', 'Noonmati', 781021, 'MBBS,MD');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_mobile`
--

CREATE TABLE IF NOT EXISTS `doctor_mobile` (
  `did` varchar(15) NOT NULL,
  `mobile_no` varchar(13) NOT NULL,
  PRIMARY KEY (`did`,`mobile_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_mobile`
--


-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `did` varchar(15) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time` varchar(15) NOT NULL,
  PRIMARY KEY (`did`,`day`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`did`, `day`, `time`) VALUES
('hk1', 'Monday', '10:00AM-3:30PM'),
('PG032', 'Tuesday', '11:30AM-2:00PM'),
('priya06', 'Saturday', '2:00PM-6:00PM'),
('ravi23', 'Thursday', '3:00PM-9:00PM'),
('vjs43', 'Wednesday', '9:30AM-11:00AM');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `department_mobile`
--
ALTER TABLE `department_mobile`
  ADD CONSTRAINT `department_mobile_ibfk_1` FOREIGN KEY (`dname`) REFERENCES `department` (`dname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor`
--
ALTER TABLE `doctor`
  ADD CONSTRAINT `doctor_ibfk_1` FOREIGN KEY (`dname`) REFERENCES `department` (`dname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_mobile`
--
ALTER TABLE `doctor_mobile`
  ADD CONSTRAINT `doctor_mobile_ibfk_1` FOREIGN KEY (`did`) REFERENCES `doctor` (`did`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`did`) REFERENCES `doctor` (`did`) ON DELETE CASCADE ON UPDATE CASCADE;
